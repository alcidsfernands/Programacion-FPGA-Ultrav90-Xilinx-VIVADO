

/***************************** Include Files *******************************/
#include "my_ip_temperatura.h"

/************************** Function Definitions ***************************/
